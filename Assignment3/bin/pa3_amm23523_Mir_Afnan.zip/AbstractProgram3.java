public abstract class AbstractProgram3 {

    public abstract TownPlan OptimalResponse(TownPlan town);

    public abstract TownPlan OptimalPosFoodStations(TownPlan town);
}
